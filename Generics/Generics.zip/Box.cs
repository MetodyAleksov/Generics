﻿using System.Collections.Generic;

namespace BoxOfT
{
    public class BoxOfT<T>
    {
        private Stack<T> elements;
        public int Count { get; private set; }
        public BoxOfT()
        {
            elements = new Stack<T>();
        }

        public void Add(T element)
        {
            elements.Push(element);
            Count = elements.Count;
        }
        public T Remove()
        {
            Count = elements.Count;
            return elements.Pop();
        }
    }
}
